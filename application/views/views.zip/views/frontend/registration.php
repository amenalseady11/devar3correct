
    <?php $main = new Main();?>


    
<?php //echo $main->headerFront()?>
<?php echo $contents ?>
<?php echo $main->footerLogin() ?>
