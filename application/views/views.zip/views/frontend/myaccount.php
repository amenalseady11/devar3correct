
    <?php $main = new Main();?>


    
<?php echo $main->myaccountheader()?>
<?php echo $contents ?>
<?php echo $main->footerFront()?>
