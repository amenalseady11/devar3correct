<!doctype html>
   <html lang="en">
      <head>
         <meta charset="utf-8">
         <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
         <meta name="description" content="">
         <meta name="author" content="">
         <link rel="icon" href="https://www.deyar.demoatcrayotech.com/printstore/img/favicon.ico">
         <title>Deyar</title>
         <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;600;700&display=swap" rel="stylesheet">
         <link href="https://www.deyar.demoatcrayotech.com/printstore/assets/deyar/skin/css/all.css" rel="stylesheet">
         <link href="https://www.deyar.demoatcrayotech.com/printstore/assets/deyar/skin/css/hover.css" rel="stylesheet">
         <!-- Bootstrap core CSS -->
         <link href="https://www.deyar.demoatcrayotech.com/printstore/assets/deyar/skin/css/bootstrap.css" rel="stylesheet">
         <!-- Custom styles for this template -->
         <link href="https://www.deyar.demoatcrayotech.com/printstore/assets/deyar/skin/css/style.css" rel="stylesheet">
         <link rel="stylesheet" href="https://www.deyar.demoatcrayotech.com/printstore/assets/deyar/skin/css/owl.carousel.min.css">
                   <link href="https://www.deyar.demoatcrayotech.com/printstore/assets/deyar/skin/css/style-new.css" rel="stylesheet">
      </head>
      <body>
         <div class="loader"></div>
         <header class="headerBar headerDark">
            <div class="headerWidth">
               <div class="headerLft">
                  <a href="<?php echo base_url()?>" class="headerBrand">
                  <img class="l" src="https://www.deyar.demoatcrayotech.com/printstore/assets/deyar/skin/img/logo-l.png" alt=""><img class="d" src="https://www.deyar.demoatcrayotech.com/printstore/assets/deyar/skin/img/logo-d.png" alt="">
                  </a>
               </div>
               <div class="headerRgt">
                  <div class="headerNav">
                     <div class="navItem headerContact">
                        <a href="#"><img class="headerIcon l" src="https://www.deyar.demoatcrayotech.com/printstore/assets/deyar/skin/img/phone-icon-l.svg" alt=""><img class="headerIcon d" src="https://www.deyar.demoatcrayotech.com/printstore/assets/deyar/skin/img/phone-icon-d.svg" alt=""> +966 114741435</a>
                     </div>
                     <div class="navItem headerLocation">
                        <a href="#"><img class="headerIcon l" src="https://www.deyar.demoatcrayotech.com/printstore/assets/deyar/skin/img/location-icon-l.svg" alt=""><img class="headerIcon d" src="https://www.deyar.demoatcrayotech.com/printstore/assets/deyar/skin/img/location-icon-d.svg" alt=""></a>
                     </div>
                     <div class="navItem headerUser dropDown">
                        <a href="<?php echo base_url()?>myaccount"><img class="headerIcon l" src="https://www.deyar.demoatcrayotech.com/printstore/assets/deyar/skin/img/user-icon-l.svg" alt=""><img class="headerIcon d" src="https://www.deyar.demoatcrayotech.com/printstore/assets/deyar/skin/img/user-icon-d.svg" alt=""></a>
                        <ul class="navBar dropDownMenu">
                           <li><a href="<?php echo base_url()?>myaccount"><i class="fas fa-user"></i> Profile</a></li>
                           <li><a href="<?php echo base_url()?>logout"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                        </ul>
                     </div>
                     <div class="navItem headerCart">
                        <a href="<?php echo base_url()?>cart"><img class="headerIcon l" src="https://www.deyar.demoatcrayotech.com/printstore/assets/deyar/skin/img/cart-icon-l.svg" alt=""><img class="headerIcon d" src="https://www.deyar.demoatcrayotech.com/printstore/assets/deyar/skin/img/cart-icon-d.svg" alt=""><span class="cartCount"><?php echo $this->cart->total_items();?></span></a>
                     </div>
                     <div class="navItem headerLaguage">
                        <a href="#">AR</a>
                     </div>
                     <div class="navItem headerMenu off">
                        <div class="hamburgerMenu">
                           <div class="hamburgerMenuIcon"></div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </header>
         <div class="mainMenu">
            <div class="menuArea">
               <div>
                  <ul class="navBar menuItem">
                     <li class="navItem">
                        <a href="#">Print & Copy</a>
                     </li>
                     <li class="navItem">
                        <a href="our-works.html">Our Work</a>
                     </li>
                     <li class="navItem">
                        <a href="<?php echo base_url()?>">All Products</a>
                     </li>
                     <li class="navItem">
                        <a href="our-clients.html">Our Client</a>
                     </li>
                     <li class="navItem">
                        <a href="who-we-are.html">Who We Are</a>
                     </li>
                     <li class="navItem">
                        <a href="contact-us.html">Contact Us</a>
                     </li>
                     <li>
                        <div class="menuLanguage">
                           <a href="#">EN</a> |
                           <a class="active" href="#">AR</a>
                        </div>
                     </li>
                  </ul>
                  <div class="menuBtn">
                     <a href="<?php echo base_url()?>" class="btnFlip" data-back="Shop Now" data-front="Shop Now"></a>
                     <div class="clearfix"></div>
                     <a href="<?php echo base_url()?>login" class="btnFlip" data-back="Login" data-front="Login"></a>
                     <div class="clearfix"></div>
                     <a class="btn animatedBtn lightBtn" href="contact-us.html#contactForm" role="button">REQUEST CALL BACK</a>
                     <a class="btn animatedBtn lightBtn" href="contact-us.html#contactForm" role="button">BULK SALES ENQUIRY</a>
                  </div>
               </div>
            </div>
         </div>
		 
         <div class="headerSpace"></div>
	<?php $main = new Main();
						if($this->uri->segment(1)=="category")
						{
							
							$id_act=$this->uri->segment(2);
							
						}
		  
		$categories=$main->getCategories();  
		  ?>	  
		  
		<div class="listMenu">
            <ul class="nav justify-content-center">
				<?php
				$j="0";
foreach ($categories as $cat)
{
		$j=$j+1;	
	if($id_act==""){if($j=="1")$id_act=$cat['category_id'];  }
				?>
	
               <li class="nav-item<?php if($id_act==$cat['category_id']) echo " active" ?>">
                  <a class="nav-link" href="<?php echo base_url()?>category/<?php echo $cat['category_id']?>"><?php echo $cat['category_name']?></a>
               </li>
				
	<?php } ?>			
              
            </ul>
         </div>
		  
        <!-- <div class="listMenu">
            <ul class="nav justify-content-center">
               <li class="nav-item active">
                  <a class="nav-link" href="<?php echo base_url()?>">Print & copy</a>
               </li>
				
				
               <li class="nav-item">
                  <a class="nav-link" href="#">Office Supplies</a>
               </li>
               <li class="nav-item">
                  <a class="nav-link" href="#">Marketing Products</a>
               </li>
               <li class="nav-item">
                  <a class="nav-link" href="#">Branding</a>
               </li>
               <li class="nav-item">
                  <a class="nav-link" href="#">Promotional Items</a>
               </li>
               <li class="nav-item">
                  <a class="nav-link" href="#">Outdoor Signage</a>
               </li>
            </ul>
         </div>-->
		