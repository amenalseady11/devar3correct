

<!-- Footer opened -->
			<div class="main-footer ht-50">
				<div class="container-fluid pd-t-0-f ht-100p">
					<span>Copyright &copy; <?php echo date('Y')?> <a href="http://deyarprint.com/">Deyar Print</a>. Designed by <a href="https://www.crayotech.com/">Crayo Tech</a> All rights reserved.</span>
				</div>
			</div>
			<!-- Footer closed -->