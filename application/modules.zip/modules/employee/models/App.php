<?php
class App extends CI_Model
{
   
    

    function employeelisting()
    {
      $this->db->order_by("employee_name", "asc");
      $res = $this->db->get('employee')->result();
		
		//echo $this->db->last_query();
		//exit;
        
       return $res;
    }
    
    
    function editemployee($employee_id)
    {
        $this->db->select('*');
        $this->db->where('employee_id', $employee_id);
        $query = $this->db->get('employee');
        $res=$query->row();
        return $res;
    }
	
	 function deleteemployee($employee_id)
    {
        
        $this->db->where('employee_id', $employee_id);
        $this->db->delete('employee');
       redirect('employee/employee_list');
    }

    

 }
?>