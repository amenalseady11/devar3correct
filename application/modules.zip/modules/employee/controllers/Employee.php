<?php
class Employee extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Main');
        $this->load->model('App');
        $this->load->library(array('ion_auth', 'form_validation'));
        $this->load->helper(array('url', 'language'));
        $this->form_validation->set_error_delimiters($this->config->item('error_start_delimiter', 'ion_auth'), $this->config->item('error_end_delimiter', 'ion_auth'));
        $this->lang->load('auth');
        $this->load->model('ion_auth_model');
        $this->load->helper('url');
        $this->load->library('grocery_CRUD');
        $this->load->library('image_CRUD');
        error_reporting(0);
    }
    function index()
    {
    
     $this->load->helper(array('form', 'url'));

        $this->load->library('form_validation');
        if($this -> ion_auth -> logged_in()==1)
        {
            $category = new App();
            $this->app = new App();
           // $data['products'] = $review->productslisting();
            $this->form_validation->set_rules('employee', 'Employee Name', 'required');
            //$this->form_validation->set_rules('rating', 'Rating', 'required');
            $employeeid=$this->input->post('employeeid');
          
			
             
              if ($this->form_validation->run() == FALSE)
            {
				
                $this->template->load('admin_blank','add_employee',$data);
            }
            else
            {
            
                $employee               = $this->input->post('employee');
				$email               = $this->input->post('email');
                $description          = $this->input->post('description');				
				$status                = $this->input->post('status');
                

                 #Department INSERT
                        $data               = array(
                            'employee_name'                   =>  $employee,
							'email'                           =>  $email,
                            'description'            =>  $description,							
                            'employee_status'                 =>  $status
                            
                        );
				
				       if($employeeid)
                        {
                           $this->db->where('employee_id', $employeeid);
                           $this->db->update('employee', $data);

                        } else
					   {
                        $complted= $this->db->insert('employee', $data);
					   }
			
                        $data['success']="success";				       
                        redirect('employee/employee_list');
				
			}

                   
             }

       
    }
	
	
	public function edit()
		{
		  $des = new App();
		  $this->app = new App();
		  $employee_id=$this->uri->segment(3);
		  $data['result']=$des->editemployee($employee_id);
		  $this->template->load('admin_blank','add_employee',$data);
		}
    
    
   
	
	public function delete()
		{
		  $dep = new App();
		  $this->app = new App();
		  $employee_id=$this->uri->segment(3);
		  $dep->deleteemployee($employee_id);
		  redirect('employee/employee_list');
		}
    
    

    function employee_list(){
        if($this->ion_auth->logged_in()==1)
        {
			$des = new App();
            $this->app = new App();
			$data['employee'] = $des->employeelisting();
			//print_r($data['categories']);
            
            $this->template->load('admin_blank', 'employee_list',$data);
        }
        else
        {
            $this->template->load('login_master','content');
        }
    }


    
}
?>