   
         <!-- 
            <div class="headerSpace"></div> -->
         <br>
         <div class="loginBlock" style="height: 150px;">
            <div class="loginTop triggerBlock">
               <div class="orderBlock">
                  <!-- <h3 class="sliderUp50d1">How to Order</h3> -->
                  <div class="orderFlow">
                     <div class="orderFlowRibbon circle-ribbon"></div>
                     <ul class="orderFlowItems">
                        <li class="orderFlowItem1 done" >
                           <p>Address Details</p>
                           <div class="icon">1</div>
                        </li>
                        <li class="orderFlowItem2 done">
                           <p>Shipping Methods</p>
                           <div class="icon">2</div>
                        </li>
                   <!--      <li class="orderFlowItem3 done">
                           <p>Payment Options</p>
                           <div class="icon">3</div>
                        </li> -->
                        <li class="orderFlowItem4 active">
                         <p>Place Order</p>
                           <div class="icon">3</div>
                        </li>
                     </ul>
                  </div>
                  <!-- <h4 class="sliderUp50d1">valuble and easy to print</h4> -->
               </div>
            </div>
         </div>
         <div class="contantBlock blockEnd">
            <div class="container">
               <div class="row">
          
             <div class="col-md-12">

                <div class="checkout-success order_complete" style="margin-top: 40px;text-align: center;">
                  <i class="fas fa-check-circle"></i>
                  <div class="heading_s1">
                    <!-- <h3>Your order is completed!</h3> -->
                    </div>
                        <p>Your order number is: <a href="<?php echo base_url()?>order_details/<?php echo $orderid?>" class="order-number"><strong>#<?php echo $orderid?></strong></a>.</p>
                <p>We'll email you an order confirmation with details and tracking info.</p>
    
    
    <div class="actions-toolbar" style="margin: auto;">
        <div class="primary">
            <a style="margin: 0px" class="btn animatedBtn darckBtn" href="<?php echo base_url()?>"><span>Continue Shopping</span></a>
        </div>
    </div>
</div>
             </div>
               </div>
            </div>
         </div>

        